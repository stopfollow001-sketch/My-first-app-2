# LoopLive Android starter

A phone-first Android prototype for looping a local video to YouTube Live over RTMPS.

## Added in this version
- Infinite single-video loop using FFmpeg `-stream_loop -1`.
- Android foreground service with an ongoing notification.
- Partial wake lock while the service is active.
- Automatic reconnect after stream process failure, using exponential backoff (5 seconds up to 60 seconds).
- Service can continue when the Activity is backgrounded; Android restrictions and manufacturer battery management may still stop it.

## Important limitations
- This is a **starter prototype, not a verified production streaming app**. The source has not been compiled or tested on a physical phone in this environment.
- It uses FFmpegKit (`com.arthenica:ffmpeg-kit-full:6.0-2`), an upstream-retired project. Artifact availability/build compatibility can change. If Gradle reports that this dependency cannot be found, the workflow cannot produce an APK until the streaming engine is replaced with a maintained, license-compatible FFmpeg build or a maintained Android RTMP library with file-input support.
- Auto-reconnect restarts the stream encoder after an FFmpeg session ends. It cannot guarantee YouTube will preserve the same live event through every interruption; check Live Control Room after reconnects.
- A process kill, force-stop, phone reboot, severe memory pressure, overheating, loss of connectivity, or manufacturer battery restrictions can still interrupt streaming. A user force-stop normally prevents automatic restart.
- 1080p encoding is CPU-intensive. Some phones may overheat or fail to encode in real time. Test with a short private/unlisted stream first.
- The command uses 8 Mbps video bitrate as a prototype setting. Adjust bitrate and resolution to your phone and upload speed; 1080p needs stable upload bandwidth with headroom.
- Check FFmpeg and codec license obligations before distributing the APK commercially. Do not remove required license notices.
- The app does not authenticate with Google OAuth; you paste the RTMPS URL and stream key manually. Treat the stream key like a password. It is not written to app storage by this prototype, but Android service intents/process memory temporarily contain it.
- Use videos you own or have permission to stream.

## Requirements
- Android phone with enough free storage for a copy of the selected video.
- YouTube channel eligible for live streaming, and live streaming enabled.
- Stable upload internet.

## Build APK using GitHub from an Android phone
1. Download and extract this ZIP on your phone.
2. Open your GitHub repository `PersonalAISuperApp` (or create a new repository named `LoopLive`).
3. Upload the **contents** of the extracted `LoopLiveAndroid` folder, not the outer folder itself. The repository root should contain `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, and `.github/`.
4. Ensure `.github/workflows/android.yml` is uploaded. If GitHub's mobile uploader hides dot-folders, use GitHub in Chrome with Desktop site enabled.
5. Commit to `main`.
6. Open repository → **Actions** → **Build LoopLive APK** → **Run workflow**. A push to `main` also starts the workflow.
7. Open the successful run → **Artifacts** → download `LoopLive-debug-apk`.
8. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from that source.

## Start a test stream
1. In YouTube Studio / Live Control Room, create a stream and copy its RTMPS ingest URL and stream key.
2. In LoopLive, choose a local video, paste the RTMPS URL and key, and tap START LOOP LIVE.
3. The foreground notification shows stream/reconnect status. Check YouTube Live Control Room's preview and stream health.
4. Tap STOP LIVE in the app to stop the FFmpeg session and remove the ongoing notification.
5. Test privately or unlisted before using a public stream.

## Expected repository layout
```
LoopLive/
├── .github/workflows/android.yml
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── AndroidManifest.xml
│       └── java/com/example/looplive/
│           ├── MainActivity.kt
│           └── StreamingService.kt
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```

## If the build fails
- `Could not find com.arthenica:ffmpeg-kit-full:6.0-2`: the archived FFmpegKit artifact is unavailable from configured repositories. Replace it with a maintained streaming engine; don't run `gradle init` (this project already has Gradle build files).
- `SDK location not found` should not occur on GitHub's hosted Android build environment; if it does, inspect the Actions log.
- If Gradle reports Java incompatibility, retain JDK 17 and check the first actual error in the log.
- Never upload `.gradle/`, `build/`, local SDK files, or stream keys.
