plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.example.looplive"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.example.looplive"
        minSdk = 26
        targetSdk = 35
        versionCode = 1
        versionName = "0.1.0"
    }
}

dependencies {
    // FFmpegKit is archived/upstream-retired. This dependency may become unavailable;
    // verify build logs before distributing. See README for alternatives and licensing.
    implementation("com.arthenica:ffmpeg-kit-full:6.0-2")
}
